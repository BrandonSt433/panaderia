from django.urls import path
from panaderiaApp.views import inicio, nosotros, listarPan, crearPan, eliminarPan,filtroPan, crearTipoPan, listarTipoPan, editarTipoPan, eliminarTipoPan, editarPan, carrito, agregar_al_carrito, eliminar_del_carrito, exportExcel


urlpatterns = [
    path('', inicio, name='mastertemplate'),
    path('pan/', listarPan, name='pan'),
    path('editarPan/<str:codigo>', editarPan, name='editarPan'),
    path('eliminarPan/<str:codigo>', eliminarPan, name='eliminarPan'),
    path('filtroPan/', filtroPan, name='filtroPan'),
    path('nosotros/', nosotros, name='nosotros'),
    path('form/', crearPan, name='form'),
    path('formTipo/', crearTipoPan, name='formTipo'),
    path('tipoPan/', listarTipoPan, name='tipoPan'),
    path('editarTipoPan/<int:id>', editarTipoPan, name='editarTipoPan'),
    path('eliminarTipoPan/<str:codigo>', eliminarTipoPan, name='eliminarTipoPan'),
    path('exportExcel/<str:tipoPan>', exportExcel, name='exportExcel'),

    path('carrito/', carrito, name='carrito'),
    path('agregar_al_carrito/<int:pan_id>/', agregar_al_carrito, name='agregar_al_carrito'),
    path('eliminar_del_carrito/<int:item_id>/', eliminar_del_carrito, name='eliminar_del_carrito')
]