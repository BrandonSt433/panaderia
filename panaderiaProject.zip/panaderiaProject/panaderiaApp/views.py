from django.shortcuts import render, redirect, get_object_or_404
from .models import tipoPan, Pan, CarritoItem
from .forms import FormPan, FormTipoPan, CarritoItemForm, FormPanFiltro
from django.contrib import messages
from django.core.files.storage import FileSystemStorage
from django.contrib.auth.decorators import permission_required, login_required
import xlwt
from django.http import HttpResponse
from django.core.paginator import Paginator
from django.http import Http404



def inicio(request):
    return render(request,'mastertemplate.html')

@login_required
def listarPan(request):
    reg = Pan.objects.all()
    page = request.GET.get('page', 1)

    try:
        paginator = Paginator(reg, 3)
        reg = paginator.page(page)
    except:
        raise Http404

    return render(request, 'panaderia/pan.html', {'panes': reg, 'paginator': paginator})


def crearPan(request):
    formulario = FormPan()
    data = {
        'titulo': 'crear pan',
        'formulario': formulario,
        'ruta': 'panaderia/pan/'
    }
    if request.method == 'POST' and request.FILES['imagen']:
        formulario = FormPan(request.POST, request.FILES)
        if formulario.is_valid():
            upload = request.FILES['imagen']
            fss = FileSystemStorage()
            fss.save(upload.name,upload)
            formulario.save()
            messages.success(request, 'el pan se ha creado con éxito')
    
    return render(request, 'panaderia/form.html', data)


def editarPan(request,codigo):
    panFk = Pan.objects.get(pk=codigo)
    formulario = FormPan(instance=panFk)
    if request.method == 'POST'and request.FILES['imagen']:
        if panFk.imagen:
            panFk.imagen.delete()
            formulario = FormPan(request.POST, request.FILES, instance=panFk)
            if formulario.is_valid():
                FileSystemStorage(location='media/pan/')
                formulario.save()
                messages.success(request, 'el pan se ha editado con éxito')
    data = {
        'titulo': 'crear pan',
        'formulario': formulario,
        'ruta': 'panaderia/pan/'
    }
    return render(request, 'panaderia/form.html', data)



def eliminarPan(request,codigo):
    panFk = Pan.objects.get(pk=codigo)
    if panFk.imagen:
        panFk.imagen.delete()
    panFk.delete()
    return redirect('/panaderia/pan')

@login_required
def filtroPan(request):
    formulario = FormPanFiltro()
    if request.method == 'POST':
        panes = Pan.objects.all()
        formulario = FormPanFiltro(request.POST)
        tipo = request.POST.get('panes','')
        if tipo != '':
            panes = panes.filter(tipoPan=tipo)
        
        data = {'formulario': formulario, 'panes': panes}

        return render(request, 'panaderia/filtroPan.html', data)
    
    data = {'formulario': formulario}
    return render(request, 'panaderia/filtroPan.html', data)

@login_required
def listarTipoPan(request):
    tipo = tipoPan.objects.all()
    data = {
        'tipos_de_pan': tipo 
        }
    return render(request, 'panaderia/tipoPan.html', data)


def crearTipoPan(request):
    formulario = FormTipoPan()
    
    if request.method == 'POST':
        formulario = FormTipoPan(request.POST)
        if formulario.is_valid():
            formulario.save()
    
    data = {
        'titulo': 'crear tipo de pan',
        'formulario': formulario,
    }

    return render(request, 'panaderia/formTipo.html', data)




def nosotros(request):
    return render(request, 'panaderia/nosotros.html')


def editarTipoPan(request,id):
    tipo = tipoPan.objects.get(id=id)
    formulario = FormTipoPan(instance=tipo)
    if request.method == 'POST':
        formulario = FormTipoPan(request.POST,instance=tipo)
        if formulario.is_valid():
            formulario.save()
            messages.success(request,'tipo de pan editada con éxito!')
  
    data = {
        'titulo':'Editar tipo pan',
        'formulario':formulario,
        'ruta': '/panaderia/tipoPan/'
    }
    return render(request,'panaderia/formTipo.html',data)


def eliminarTipoPan(request,codigo):
    tipo = tipoPan.objects.get(pk=codigo) 
    tipo.delete()
    return redirect('/panaderia/tipoPan')

@login_required
def carrito(request):
    carrito_items = CarritoItem.objects.filter()
    total = sum(item.subtotal() for item in carrito_items)
    return render(request, 'panaderia/carrito.html', {'carrito_items': carrito_items, 'total': total})


def agregar_al_carrito(request, pan_id):
    pan = get_object_or_404(Pan, id=pan_id)

    if request.method == 'POST':
        form = CarritoItemForm(request.POST)
        if form.is_valid():
            form.instance.usuario = request.user
            form.instance.pan = pan
            form.save()
            return redirect('carrito')
    else:
        form = CarritoItemForm(initial={'pan': pan_id})

    return render(request, 'panaderia/carrito.html', {'form': form})


def eliminar_del_carrito(request, item_id):
    CarritoItem.objects.filter(id=item_id).delete()
    return redirect('carrito')

def exportExcel(request,tipoPan):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename=pa.xls'
    archivo = xlwt.Workbook(encoding='utf-8')
    hoja = archivo.add_sheet('Pan')
    row_num = 0
    font_style = xlwt.XFStyle()
    font_style.font.bold = True
    columnas = ['Código Barra','Nombre','tipoPan','Precio','Descripción']

    for col_num in range(len(columnas)):
        hoja.write(row_num,col_num,columnas[col_num],font_style)
   
    font_style = xlwt.XFStyle()
    filas = Pan.objects.all().values_list('codigo_barra','nombre',
            'tipoPan__nombre','precio','descripcion')
    if tipoPan != 0:
        filas = filas.filter(tipoPan=tipoPan)
    for f in filas:
        row_num+=1
        for col_num in range(len(f)):
            hoja.write(row_num,col_num,f[col_num],font_style)
    archivo.save(response)
    return response



