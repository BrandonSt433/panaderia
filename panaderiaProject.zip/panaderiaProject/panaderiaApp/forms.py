from django import forms
from .models import Pan, tipoPan, CarritoItem

class FormTipoPan(forms.ModelForm):
    class Meta:
        model = tipoPan
        fields = '__all__'
        widgets = {
            'nombre':forms.TextInput(
                attrs={
                    'class':'form-control'
                }
            )
        }

class FormPan(forms.ModelForm):
    class Meta:
        model = Pan
        fields = ['codigo_barra','nombre','precio', 'descripcion','tipoPan',
                  'imagen']
        widgets = {
            'codigo_barra':forms.TextInput(attrs={'class':'form-control'}),
            'nombre':forms.TextInput(attrs={'class':'form-control'}),
            'precio':forms.NumberInput(attrs={'class':'form-control'}),
            'descripcion':forms.Textarea(attrs={'class':'form-control','rows':'3'}),
            'tipoPan':forms.Select(attrs={'class':'form-select'}),
            'imagen':forms.FileInput(attrs={'class':'form-control'})
        }
class FormPanFiltro(forms.Form):
    panes = forms.ModelChoiceField(
        queryset=tipoPan.objects.all(),
        required=False,
        empty_label='Todas los tipos de pan',
        widget=forms.Select(attrs={'class':'form-select'})
    )

class CarritoItemForm(forms.ModelForm):
    class Meta:
        model = CarritoItem
        fields = ['pan', 'cantidad']
        widgets = {
            'pan':forms.Select(attrs={'class':'form-select'}),
            'cantidad': forms.NumberInput(attrs={'class': 'form-control'}),
        }