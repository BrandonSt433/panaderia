from django.contrib import admin
from .models import Pan, tipoPan, CarritoItem

admin.site.register(Pan)
admin.site.register(tipoPan)
admin.site.register(CarritoItem)
