from django.db import models
from django.contrib.auth.models import User

class tipoPan(models.Model):
    nombre = models.CharField(max_length=30)
    def __str__(self):
        return self.nombre
    class Meta:
        db_table = 'tipoPan'

class Pan(models.Model):
    codigo_barra = models.CharField(primary_key=True,max_length=60)
    nombre = models.CharField(max_length=60, verbose_name='nombre')
    precio = models.IntegerField()
    descripcion = models.TextField(max_length=300,verbose_name='descricion',null=True)
    tipoPan = models.ForeignKey(tipoPan,on_delete=models.RESTRICT)
    imagen = models.ImageField(upload_to='pan',verbose_name='imagen', null=True)
    def __str__(self):
        return self.nombre
    class Meta:
        db_table='Pan'
    def get_add_to_cart_url(self):
        return reverse('agregar_al_carrito', args=[str(self.id)])

class CarritoItem(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE, default=1)
    pan = models.ForeignKey('Pan', on_delete=models.CASCADE)
    cantidad = models.PositiveIntegerField(default=1)

    def subtotal(self):
        return self.cantidad * self.pan.precio
    