from django.urls import path
from authApp.views import signup, logout, signin, cerrarSesion



urlpatterns = [
    path('registration/signup/',signup,name='signup'),
    path('logout/',cerrarSesion, name= 'logout'),
    path('registration/login/',signin, name='signin')
]
