from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User, Group
from django.contrib.auth import login, logout, authenticate
from django.db import IntegrityError
from django.contrib import messages


def signup(request):
    data = {
        'form': UserCreationForm,
        'nombre': 'Registrarse'
    }

    if request.method == 'GET':
        return render(request, 'registration/signup.html', data)
    else:
        if request.POST['password1'] == request.POST['password2']:
            try:
                user = User.objects.create_user(username=request.POST['username'], password=request.POST['password1'])
                group = Group.objects.get(name="usuarios normales")
                user.groups.add(group)
                user.save()
                messages.success(request,'Cuenta creada con éxito!!')
            except IntegrityError:
                messages.error()
            return render(request, 'registration/login.html', data)

def cerrarSesion(request):
    logout(request)
    return redirect('signin')

def signin(request):
    data = {
    "form": AuthenticationForm,
    "title": "Iniciar sesión",
    "error": "Usuario o contraseña incorrectos, intente de nuevo."
    }
    if request.method == 'GET':
         return render(request,"panaderia/pan.html", data)

    else:
         user = authenticate(request, username = request.POST['username'],password = request.POST['password'])
         if user is None:
             return render(request,'registration/login.html', data)
         else:
             login(request, user)
             return render(request, 'mastertemplate.html')   